# Mayra AI MVP intentionally keeps this empty.
# Add release-specific rules here if you enable shrinking/obfuscation.
