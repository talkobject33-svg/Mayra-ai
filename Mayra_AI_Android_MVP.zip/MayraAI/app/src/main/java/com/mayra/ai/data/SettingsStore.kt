package com.mayra.ai.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore("mayra_settings")

data class AppSettings(
    val model: String = "gemini-3.8-flash",
    val temperature: Float = 0.7f,
    val language: String = "Auto",
    val preferredName: String = "",
    val style: String = "Warm & casual",
    val memoryEnabled: Boolean = true,
    val ttsEnabled: Boolean = true,
    val ttsRate: Float = 1.0f
)

class SettingsStore(private val context: Context) {
    private object Keys {
        val model = stringPreferencesKey("model")
        val temperature = floatPreferencesKey("temperature")
        val language = stringPreferencesKey("language")
        val preferredName = stringPreferencesKey("preferred_name")
        val style = stringPreferencesKey("style")
        val memoryEnabled = booleanPreferencesKey("memory_enabled")
        val ttsEnabled = booleanPreferencesKey("tts_enabled")
        val ttsRate = floatPreferencesKey("tts_rate")
    }

    val settings: Flow<AppSettings> = context.dataStore.data.map { p ->
        AppSettings(
            model = p[Keys.model] ?: "gemini-3.8-flash",
            temperature = p[Keys.temperature] ?: 0.7f,
            language = p[Keys.language] ?: "Auto",
            preferredName = p[Keys.preferredName] ?: "",
            style = p[Keys.style] ?: "Warm & casual",
            memoryEnabled = p[Keys.memoryEnabled] ?: true,
            ttsEnabled = p[Keys.ttsEnabled] ?: true,
            ttsRate = p[Keys.ttsRate] ?: 1.0f
        )
    }

    suspend fun update(transform: (MutablePreferences) -> Unit) {
        context.dataStore.edit(transform)
    }

    suspend fun save(s: AppSettings) {
        context.dataStore.edit { p ->
            p[Keys.model] = s.model
            p[Keys.temperature] = s.temperature
            p[Keys.language] = s.language
            p[Keys.preferredName] = s.preferredName
            p[Keys.style] = s.style
            p[Keys.memoryEnabled] = s.memoryEnabled
            p[Keys.ttsEnabled] = s.ttsEnabled
            p[Keys.ttsRate] = s.ttsRate
        }
    }
}
