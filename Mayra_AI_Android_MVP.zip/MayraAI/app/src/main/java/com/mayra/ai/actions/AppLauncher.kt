package com.mayra.ai.actions

import android.content.Context
import android.content.Intent
import android.net.Uri

class AppLauncher(private val context: Context) {
    private val aliases = mapOf(
        "youtube" to "com.google.android.youtube",
        "chrome" to "com.android.chrome",
        "whatsapp" to "com.whatsapp",
        "settings" to "android.settings.SETTINGS"
    )

    fun open(target: String): Result<String> {
        val key = target.trim().lowercase()
        return runCatching {
            if (key == "settings" || key == "open settings") {
                context.startActivity(Intent(android.provider.Settings.ACTION_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                })
                return@runCatching "Settings opened."
            }

            val packageName = aliases[key]
            if (packageName != null) {
                val launch = context.packageManager.getLaunchIntentForPackage(packageName)
                    ?: error("$target is not installed.")
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launch)
                return@runCatching "$target opened."
            }

            val apps = context.packageManager.getInstalledApplications(0)
                .filter {
                    context.packageManager.getApplicationLabel(it).toString()
                        .contains(target, ignoreCase = true)
                }

            when {
                apps.isEmpty() -> error("I couldn't find an installed app named \"$target\".")
                apps.size > 1 -> error("I found multiple apps matching \"$target\". Please use a more specific name.")
                else -> {
                    val intent = context.packageManager.getLaunchIntentForPackage(apps.first().packageName)
                        ?: error("That app cannot be launched.")
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(intent)
                    "${context.packageManager.getApplicationLabel(apps.first())} opened."
                }
            }
        }
    }

    fun openYouTubeSearch(query: String) {
        val encoded = Uri.encode(query)
        val appIntent = Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:$encoded"))
        val webIntent = Intent(
            Intent.ACTION_VIEW,
            Uri.parse("https://www.youtube.com/results?search_query=$encoded")
        )
        val resolved = if (appIntent.resolveActivity(context.packageManager) != null) appIntent else webIntent
        resolved.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(resolved)
    }
}
