package com.mayra.ai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.mayra.ai.actions.AppLauncher
import com.mayra.ai.data.AppSettings
import com.mayra.ai.voice.VoiceManager
import kotlinx.coroutines.launch

private val Bg = Color(0xFF080713)
private val Card = Color(0xFF141124)
private val Purple = Color(0xFF9B6CFF)
private val Pink = Color(0xFFFF5EC4)
private val Cyan = Color(0xFF62D9FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MayraApp() }
    }
}

@Composable
fun MayraApp(vm: MainViewModel = viewModel()) {
    val settings by vm.settings.collectAsState()
    val state by vm.state.collectAsState()
    val messages by vm.messages.collectAsState()
    val conversations by vm.conversations.collectAsState()
    var screen by remember { mutableStateOf("home") }
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()

    var voiceStatus by remember { mutableStateOf("Ready") }
    var voice by remember {
        mutableStateOf<VoiceManager?>(null)
    }

    DisposableEffect(Unit) {
        val manager = VoiceManager(
            context = context,
            onText = { text -> vm.updateInput(text) },
            onState = { voiceStatus = it }
        )
        voice = manager
        onDispose { manager.shutdown() }
    }

    val micPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) voice?.startListening(languageTag(settings.language.toSpeechTag()))
        else Toast.makeText(context, "Microphone permission is required for voice input.", Toast.LENGTH_LONG).show()
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg,
            surface = Card,
            primary = Purple,
            secondary = Pink,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            when (screen) {
                "home" -> HomeScreen(
                    vm, state, messages, settings,
                    onOpen = { screen = it },
                    onMic = {
                        if (context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
                            voice?.startListening(settings.language.toSpeechTag())
                        else micPermission.launch(Manifest.permission.RECORD_AUDIO)
                    },
                    onSpeak = { text -> if (settings.ttsEnabled) voice?.speak(text, settings.ttsRate) },
                    voiceStatus = voiceStatus
                )
                "chat" -> ChatScreen(vm, messages, settings, onBack = { screen = "home" }, onSpeak = { voice?.speak(it, settings.ttsRate) })
                "settings" -> SettingsScreen(vm, settings, onBack = { screen = "home" })
                "history" -> HistoryScreen(vm, conversations, onBack = { screen = "home" })
                "coding" -> CodingScreen(vm, onBack = { screen = "home" })
                "phone" -> PhoneActionsScreen(onBack = { screen = "home" })
                "youtube" -> YouTubeScreen(onBack = { screen = "home" })
                "memory" -> MemoryScreen(vm, settings, onBack = { screen = "home" })
                "about" -> AboutScreen(onBack = { screen = "home" })
                "voice" -> VoiceScreen(
                    vm, settings, voiceStatus,
                    onBack = { screen = "home" },
                    onMic = {
                        if (context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
                            voice?.startListening(settings.language.toSpeechTag())
                        else micPermission.launch(Manifest.permission.RECORD_AUDIO)
                    },
                    onStop = { voice?.stopListening() },
                    onSpeak = { voice?.speak(it, settings.ttsRate) }
                )
            }
        }
    }
}

@Composable
private fun HomeScreen(
    vm: MainViewModel,
    state: MayraUiState,
    messages: List<com.mayra.ai.data.ChatMessage>,
    settings: AppSettings,
    onOpen: (String) -> Unit,
    onMic: () -> Unit,
    onSpeak: (String) -> Unit,
    voiceStatus: String
) {
    var input by remember { mutableStateOf("") }
    val lastAnswer = messages.lastOrNull { it.role == "model" }?.text
    val infinite = rememberInfiniteTransition(label = "orb")
    val scale by infinite.animateFloat(
        1f, 1.08f,
        animationSpec = infiniteRepeatable(tween(1400), RepeatMode.Reverse),
        label = "orbScale"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(listOf(Color(0xFF10091F), Bg, Bg))
            )
            .padding(18.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("MAYRA", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                Text(state.status, color = if (state.isThinking) Pink else Cyan, fontSize = 13.sp)
            }
            IconButton(onClick = { onOpen("settings") }) {
                Icon(Icons.Default.Settings, "Settings", tint = Color.White)
            }
        }

        Spacer(Modifier.height(18.dp))

        Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
            Box(
                Modifier
                    .size(220.dp)
                    .scale(scale)
                    .background(
                        Brush.radialGradient(listOf(Purple.copy(.8f), Pink.copy(.25f), Color.Transparent)),
                        CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    Modifier.size(132.dp).background(
                        Brush.radialGradient(listOf(Cyan, Purple, Pink)),
                        CircleShape
                    ),
                    contentAlignment = Alignment.Center
                ) {
                    Text("M", color = Color.White, fontSize = 54.sp, fontWeight = FontWeight.Black)
                }
            }
        }

        if (lastAnswer != null) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Card.copy(alpha = .92f)),
                shape = RoundedCornerShape(22.dp),
                modifier = Modifier.fillMaxWidth().heightIn(max = 150.dp)
            ) {
                Text(
                    lastAnswer,
                    Modifier.padding(16.dp),
                    color = Color.White,
                    maxLines = 6,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(Modifier.height(10.dp))
        }

        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            QuickButton("Coding", Icons.Default.Code) { onOpen("coding") }
            QuickButton("YouTube", Icons.Default.PlayArrow) { onOpen("youtube") }
            QuickButton("Apps", Icons.Default.Apps) { onOpen("phone") }
            QuickButton("Voice", Icons.Default.Mic) { onOpen("voice") }
        }

        Spacer(Modifier.height(10.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it; vm.updateInput(it) },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Talk to Mayra…") },
                singleLine = true,
                shape = RoundedCornerShape(18.dp)
            )
            Spacer(Modifier.width(8.dp))
            FilledIconButton(onClick = onMic, modifier = Modifier.size(54.dp)) {
                Icon(Icons.Default.Mic, "Speak")
            }
            Spacer(Modifier.width(6.dp))
            FilledIconButton(
                onClick = { vm.send(input); input = "" },
                modifier = Modifier.size(54.dp)
            ) { Icon(Icons.Default.Send, "Send") }
        }

        if (voiceStatus != "Ready") {
            Text(voiceStatus, color = Cyan, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
        }

        state.error?.let {
            Text(
                it,
                color = Color(0xFFFF8A9B),
                fontSize = 12.sp,
                modifier = Modifier.padding(top = 6.dp).clickable { vm.clearError() }
            )
        }
    }
}

@Composable
private fun QuickButton(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    OutlinedButton(onClick = onClick, modifier = Modifier.weight(1f), contentPadding = PaddingValues(6.dp)) {
        Icon(icon, null, Modifier.size(17.dp))
        Spacer(Modifier.width(3.dp))
        Text(label, fontSize = 11.sp)
    }
}

@Composable
private fun TopBar(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") }
        Text(title, fontSize = 23.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ChatScreen(vm: MainViewModel, messages: List<com.mayra.ai.data.ChatMessage>, settings: AppSettings, onBack: () -> Unit, onSpeak: (String) -> Unit) {
    var input by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize()) {
        TopBar("Mayra Chat", onBack)
        LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp)) {
            items(messages) { m ->
                val isUser = m.role == "user"
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = if (isUser) Purple.copy(.28f) else Card),
                        shape = RoundedCornerShape(18.dp),
                        modifier = Modifier.padding(vertical = 5.dp).widthIn(max = 330.dp)
                    ) {
                        Column(Modifier.padding(12.dp)) {
                            Text(m.text)
                            if (!isUser) {
                                TextButton(onClick = { onSpeak(m.text) }) { Text("Speak") }
                            }
                        }
                    }
                }
            }
        }
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(input, { input = it; vm.updateInput(it) }, Modifier.weight(1f), singleLine = true)
            IconButton(onClick = { vm.send(input); input = "" }) { Icon(Icons.Default.Send, "Send") }
        }
    }
}

@Composable
private fun SettingsScreen(vm: MainViewModel, settings: AppSettings, onBack: () -> Unit) {
    var key by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var model by remember(settings.model) { mutableStateOf(settings.model) }
    var name by remember(settings.preferredName) { mutableStateOf(settings.preferredName) }
    var language by remember(settings.language) { mutableStateOf(settings.language) }
    var tts by remember(settings.ttsEnabled) { mutableStateOf(settings.ttsEnabled) }
    val scope = rememberCoroutineScope()

    Column(Modifier.fillMaxSize()) {
        TopBar("Settings", onBack)
        LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
            item {
                Text("Gemini API", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = key,
                    onValueChange = { key = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Gemini API key") },
                    placeholder = { Text(if (vm.hasApiKey()) vm.readApiKeyMasked() else "Paste your key") }
                )
                Row {
                    Button(onClick = { vm.saveApiKey(key); key = ""; message = "API key saved securely." }) { Text("Save") }
                    Spacer(Modifier.width(8.dp))
                    OutlinedButton(onClick = { vm.deleteApiKey(); message = "API key deleted." }) { Text("Delete") }
                    Spacer(Modifier.width(8.dp))
                    OutlinedButton(onClick = { vm.testConnection { message = it } }) { Text("Test") }
                }
                Text(message, color = Cyan, fontSize = 12.sp)
                Spacer(Modifier.height(16.dp))
                Text("Model", fontWeight = FontWeight.Bold)
                OutlinedTextField(model, { model = it }, Modifier.fillMaxWidth(), singleLine = true)
                Text("Default: gemini-3.8-flash. You can enter another currently available model.", fontSize = 12.sp)
                Spacer(Modifier.height(10.dp))
                Text("Preferred nickname", fontWeight = FontWeight.Bold)
                OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), singleLine = true)
                Spacer(Modifier.height(10.dp))
                Text("Language", fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Auto", "বাংলা", "English", "Hindi").forEach {
                        FilterChip(selected = language == it, onClick = { language = it }, label = { Text(it) })
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Voice replies", Modifier.weight(1f))
                    Switch(tts, { tts = it })
                }
                Spacer(Modifier.height(10.dp))
                Button(onClick = {
                    scope.launch {
                        vm.settingsStore.save(
                            settings.copy(model = model.trim(), preferredName = name.trim(), language = language, ttsEnabled = tts)
                        )
                        message = "Settings saved."
                    }
                }) { Text("Save settings") }

                Spacer(Modifier.height(20.dp))
                Text("Privacy", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text(
                    "Gemini receives the conversation text you send. The API key is stored locally using Android Keystore-backed encryption. Conversation history is stored locally in Room.",
                    fontSize = 13.sp
                )
                Spacer(Modifier.height(10.dp))
                OutlinedButton(onClick = { vm.clearHistory(); message = "Local history cleared." }) { Text("Clear local chat history") }
            }
        }
    }
}

@Composable
private fun HistoryScreen(vm: MainViewModel, conversations: List<com.mayra.ai.data.ConversationEntity>, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        TopBar("Conversation History", onBack)
        LazyColumn(Modifier.fillMaxSize().padding(12.dp)) {
            items(conversations) { c ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { vm.selectConversation(c.id) }) {
                    Column(Modifier.padding(14.dp)) {
                        Text(c.title, fontWeight = FontWeight.Bold)
                        Text("Tap to open", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun CodingScreen(vm: MainViewModel, onBack: () -> Unit) {
    var prompt by remember { mutableStateOf("Help me write Kotlin code for ") }
    Column(Modifier.fillMaxSize()) {
        TopBar("Coding Assistant", onBack)
        Text(
            "Ask Mayra to generate, explain or debug code. Code is not executed automatically.",
            Modifier.padding(horizontal = 16.dp),
            fontSize = 13.sp
        )
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(prompt, { prompt = it }, Modifier.fillMaxWidth().padding(horizontal = 16.dp).height(150.dp))
        Button(
            onClick = { vm.send(prompt) },
            modifier = Modifier.padding(16.dp)
        ) { Text("Ask Mayra") }
    }
}

@Composable
private fun PhoneActionsScreen(onBack: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val launcher = remember { AppLauncher(context) }
    var target by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize()) {
        TopBar("Phone Actions", onBack)
        Text("Open installed apps using Android intents.", Modifier.padding(16.dp))
        OutlinedTextField(target, { target = it }, Modifier.fillMaxWidth().padding(horizontal = 16.dp), label = { Text("App name") })
        Button(onClick = { result = launcher.open(target).getOrElse { it.message ?: "Failed" } }, Modifier.padding(16.dp)) {
            Text("Open app")
        }
        Text(result, Modifier.padding(horizontal = 16.dp), color = Cyan)
    }
}

@Composable
private fun YouTubeScreen(onBack: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val launcher = remember { AppLauncher(context) }
    var query by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize()) {
        TopBar("YouTube Search", onBack)
        Text("Search opens the official YouTube app when available, otherwise the website.", Modifier.padding(16.dp), fontSize = 13.sp)
        OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth().padding(16.dp), label = { Text("Song, artist or video") })
        Button(onClick = { launcher.openYouTubeSearch(query) }, Modifier.padding(horizontal = 16.dp)) { Text("Search YouTube") }
    }
}

@Composable
private fun MemoryScreen(vm: MainViewModel, settings: AppSettings, onBack: () -> Unit) {
    var enabled by remember(settings.memoryEnabled) { mutableStateOf(settings.memoryEnabled) }
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize()) {
        TopBar("Memory", onBack)
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Conversation memory", fontWeight = FontWeight.Bold)
                Text("Mayra can use recent local conversation history as context.")
            }
            Switch(enabled, {
                enabled = it
                scope.launch { vm.settingsStore.save(settings.copy(memoryEnabled = it)) }
            })
        }
        Text("Stored preferences and chat history can be cleared from Settings.", Modifier.padding(16.dp))
    }
}

@Composable
private fun VoiceScreen(vm: MainViewModel, settings: AppSettings, voiceStatus: String, onBack: () -> Unit, onMic: () -> Unit, onStop: () -> Unit, onSpeak: (String) -> Unit) {
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        TopBar("Voice Assistant", onBack)
        Spacer(Modifier.height(50.dp))
        Text("Mayra", fontSize = 42.sp, fontWeight = FontWeight.Black)
        Text(voiceStatus, color = Cyan)
        Spacer(Modifier.height(35.dp))
        FilledIconButton(onClick = onMic, modifier = Modifier.size(110.dp)) { Icon(Icons.Default.Mic, "Start", Modifier.size(52.dp)) }
        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = onStop) { Text("Stop listening") }
        Text(
            "Uses Android SpeechRecognizer and TextToSpeech. Continuous background wake-word listening is not enabled in this MVP.",
            Modifier.padding(24.dp),
            fontSize = 13.sp
        )
    }
}

@Composable
private fun AboutScreen(onBack: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        TopBar("About Mayra", onBack)
        Text("Mayra AI", Modifier.padding(20.dp), fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text(
            "A phone-first AI companion MVP built with Kotlin, Jetpack Compose, Room, DataStore, Android voice APIs and the official Gemini API.",
            Modifier.padding(horizontal = 20.dp)
        )
    }
}

private fun String.toSpeechTag(): String = when (this) {
    "বাংলা" -> "bn-BD"
    "Hindi" -> "hi-IN"
    "English" -> "en-US"
    else -> "bn-BD"
}
