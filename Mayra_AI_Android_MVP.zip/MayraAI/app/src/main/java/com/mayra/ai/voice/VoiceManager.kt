package com.mayra.ai.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.*
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import java.util.Locale

class VoiceManager(
    private val context: Context,
    private val onText: (String) -> Unit,
    private val onState: (String) -> Unit
) : RecognitionListener, TextToSpeech.OnInitListener {

    private val recognizer = SpeechRecognizer.createSpeechRecognizer(context)
    private var tts: TextToSpeech? = null

    init {
        recognizer.setRecognitionListener(this)
        tts = TextToSpeech(context, this)
    }

    fun startListening(languageTag: String = "bn-BD") {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onState("Speech recognition is unavailable.")
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }
        onState("Listening")
        recognizer.startListening(intent)
    }

    fun stopListening() {
        recognizer.stopListening()
        onState("Ready")
    }

    fun speak(text: String, rate: Float = 1f) {
        tts?.setSpeechRate(rate.coerceIn(0.5f, 2f))
        onState("Speaking")
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "mayra-response")
    }

    fun stopSpeaking() {
        tts?.stop()
        onState("Ready")
    }

    fun shutdown() {
        recognizer.destroy()
        tts?.stop()
        tts?.shutdown()
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.US
            val voices = tts?.voices.orEmpty()
            val preferred = voices.firstOrNull {
                val n = it.name.lowercase()
                !it.isNetworkConnectionRequired &&
                        (n.contains("female") || n.contains("woman"))
            }
            if (preferred != null) tts?.voice = preferred
        }
    }

    override fun onResults(results: Bundle?) {
        val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            ?.firstOrNull().orEmpty()
        if (text.isNotBlank()) onText(text)
        onState("Ready")
    }

    override fun onError(error: Int) {
        onState("Voice error: $error")
    }

    override fun onBeginningOfSpeech() { onState("Listening") }
    override fun onEndOfSpeech() { onState("Processing voice") }
    override fun onReadyForSpeech(params: Bundle?) { onState("Listening") }
    override fun onPartialResults(partialResults: Bundle?) {}
    override fun onRmsChanged(rmsdB: Float) {}
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onEvent(eventType: Int, params: Bundle?) {}
}
