package com.mayra.ai.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface MayraDao {
    @Query("SELECT * FROM conversations ORDER BY updatedAt DESC")
    fun conversations(): Flow<List<ConversationEntity>>

    @Query("SELECT * FROM messages WHERE conversationId = :id ORDER BY timestamp ASC")
    fun messages(id: String): Flow<List<MessageEntity>>

    @Insert
    suspend fun insertConversation(item: ConversationEntity)

    @Insert
    suspend fun insertMessage(item: MessageEntity)

    @Query("UPDATE conversations SET title = :title, updatedAt = :updatedAt WHERE id = :id")
    suspend fun renameConversation(id: String, title: String, updatedAt: Long = System.currentTimeMillis())

    @Query("UPDATE conversations SET updatedAt = :updatedAt WHERE id = :id")
    suspend fun touchConversation(id: String, updatedAt: Long = System.currentTimeMillis())

    @Delete
    suspend fun deleteConversation(item: ConversationEntity)

    @Query("DELETE FROM messages WHERE conversationId = :id")
    suspend fun deleteMessages(id: String)

    @Query("DELETE FROM messages")
    suspend fun clearMessages()

    @Query("DELETE FROM conversations")
    suspend fun clearConversations()
}
