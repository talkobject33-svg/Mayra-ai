package com.mayra.ai

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mayra.ai.ai.GeminiRepository
import com.mayra.ai.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

data class MayraUiState(
    val status: String = "Online",
    val input: String = "",
    val isThinking: Boolean = false,
    val error: String? = null
)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val db = MayraDatabase.get(app)
    private val dao = db.dao()
    val settingsStore = SettingsStore(app)
    val settings = settingsStore.settings.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), AppSettings()
    )
    val conversations = dao.conversations().stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    private val keyStore = SecureKeyStore(app)
    private val gemini = GeminiRepository()
    private val _state = MutableStateFlow(MayraUiState())
    val state = _state.asStateFlow()

    var currentConversationId: String = UUID.randomUUID().toString()
        private set

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages = _messages.asStateFlow()

    init {
        viewModelScope.launch { ensureConversation() }
    }

    private suspend fun ensureConversation() {
        if (dao.conversations().first().none { it.id == currentConversationId }) {
            dao.insertConversation(ConversationEntity(currentConversationId, "New conversation"))
        }
        dao.messages(currentConversationId).collect { rows ->
            _messages.value = rows.map { ChatMessage(it.role, it.text) }
        }
    }

    fun selectConversation(id: String) {
        currentConversationId = id
        viewModelScope.launch {
            dao.messages(id).collect { rows ->
                if (currentConversationId == id) {
                    _messages.value = rows.map { ChatMessage(it.role, it.text) }
                }
            }
        }
    }

    fun updateInput(value: String) { _state.update { it.copy(input = value) } }

    fun send(textOverride: String? = null) {
        val text = (textOverride ?: _state.value.input).trim()
        if (text.isBlank() || _state.value.isThinking) return
        viewModelScope.launch {
            val key = keyStore.read()
            if (key.isNullOrBlank()) {
                _state.update { it.copy(error = "Add your Gemini API key in Settings → Gemini API.") }
                return@launch
            }
            val s = settings.value
            val user = ChatMessage("user", text)
            _messages.update { it + user }
            dao.insertMessage(MessageEntity(conversationId = currentConversationId, role = "user", text = text))
            _state.update { it.copy(input = "", isThinking = true, status = "Thinking", error = null) }

            val result = gemini.send(
                apiKey = key,
                model = s.model,
                history = _messages.value.dropLast(1),
                userText = text,
                settings = s,
                systemPrompt = systemPrompt(s)
            )

            result.onSuccess { answer ->
                val ai = ChatMessage("model", answer)
                _messages.update { it + ai }
                dao.insertMessage(MessageEntity(conversationId = currentConversationId, role = "model", text = answer))
                dao.touchConversation(currentConversationId)
                if (dao.conversations().first().firstOrNull { it.id == currentConversationId }?.title == "New conversation") {
                    dao.renameConversation(currentConversationId, text.take(42))
                }
                _state.update { it.copy(isThinking = false, status = "Online") }
            }.onFailure { e ->
                _state.update {
                    it.copy(
                        isThinking = false,
                        status = "Online",
                        error = e.message ?: "Unknown Gemini error."
                    )
                }
            }
        }
    }

    fun testConnection(onResult: (String) -> Unit) {
        viewModelScope.launch {
            val key = keyStore.read().orEmpty()
            if (key.isBlank()) { onResult("No API key saved."); return@launch }
            gemini.test(key, settings.value.model).fold(
                onSuccess = { onResult("Connected: $it") },
                onFailure = { onResult(it.message ?: "Connection failed.") }
            )
        }
    }

    fun saveApiKey(value: String) = keyStore.save(value.trim())
    fun deleteApiKey() = keyStore.delete()
    fun hasApiKey(): Boolean = !keyStore.read().isNullOrBlank()
    fun readApiKeyMasked(): String = keyStore.read()?.let { "••••••••" + it.takeLast(4) } ?: ""

    fun clearError() { _state.update { it.copy(error = null) } }

    fun clearHistory() {
        viewModelScope.launch {
            dao.clearMessages()
            dao.clearConversations()
            currentConversationId = UUID.randomUUID().toString()
            dao.insertConversation(ConversationEntity(currentConversationId, "New conversation"))
            _messages.value = emptyList()
        }
    }

    fun newConversation() {
        viewModelScope.launch {
            currentConversationId = UUID.randomUUID().toString()
            dao.insertConversation(ConversationEntity(currentConversationId, "New conversation"))
            _messages.value = emptyList()
        }
    }

    private fun systemPrompt(s: AppSettings): String {
        val name = s.preferredName.ifBlank { "friend" }
        return """
            You are Mayra, a warm, intelligent, friendly female AI companion and personal assistant.
            Speak naturally in the user's language. The user prefers: ${s.language}.
            User nickname: $name.
            Style: ${s.style}.
            Be warm and lightly playful when appropriate, but never controlling, manipulative,
            coercive, or encouraging emotional dependency. You are an AI, not a human.
            Help with coding, studies, daily tasks and entertainment. Respect privacy, consent and boundaries.
            Never claim you performed a real-world action unless the app confirms success.
            For arithmetic, reason carefully and show calculations when useful.
        """.trimIndent()
    }
}
