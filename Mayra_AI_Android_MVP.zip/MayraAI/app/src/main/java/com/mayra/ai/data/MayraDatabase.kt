package com.mayra.ai.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [MessageEntity::class, ConversationEntity::class],
    version = 1,
    exportSchema = false
)
abstract class MayraDatabase : RoomDatabase() {
    abstract fun dao(): MayraDao

    companion object {
        @Volatile private var INSTANCE: MayraDatabase? = null

        fun get(context: Context): MayraDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    MayraDatabase::class.java,
                    "mayra.db"
                ).build().also { INSTANCE = it }
            }
    }
}
