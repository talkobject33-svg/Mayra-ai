package com.mayra.ai.ai

import com.mayra.ai.data.AppSettings
import com.mayra.ai.data.ChatMessage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class GeminiRepository {
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val jsonMedia = "application/json; charset=utf-8".toMediaType()

    suspend fun send(
        apiKey: String,
        model: String,
        history: List<ChatMessage>,
        userText: String,
        settings: AppSettings,
        systemPrompt: String
    ): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            require(apiKey.isNotBlank()) { "Gemini API key is missing." }
            require(model.isNotBlank()) { "Gemini model is missing." }

            val contents = JSONArray()
            history.takeLast(24).forEach { m ->
                val item = JSONObject()
                    .put("role", if (m.role == "user") "user" else "model")
                    .put("parts", JSONArray().put(JSONObject().put("text", m.text)))
                contents.put(item)
            }
            contents.put(
                JSONObject()
                    .put("role", "user")
                    .put("parts", JSONArray().put(JSONObject().put("text", userText)))
            )

            val body = JSONObject()
                .put(
                    "systemInstruction",
                    JSONObject().put(
                        "parts",
                        JSONArray().put(JSONObject().put("text", systemPrompt))
                    )
                )
                .put("contents", contents)
                .put(
                    "generationConfig",
                    JSONObject()
                        .put("temperature", settings.temperature.coerceIn(0f, 2f))
                )

            val url = "https://generativelanguage.googleapis.com/v1beta/models/" +
                    "${model}:generateContent"

            val request = Request.Builder()
                .url(url)
                .addHeader("x-goog-api-key", apiKey)
                .post(body.toString().toRequestBody(jsonMedia))
                .build()

            client.newCall(request).execute().use { response ->
                val raw = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val msg = runCatching {
                        JSONObject(raw).optJSONObject("error")?.optString("message")
                    }.getOrNull().orEmpty()
                    error("Gemini error ${response.code}: ${msg.ifBlank { response.message }}")
                }

                val root = JSONObject(raw)
                val candidates = root.optJSONArray("candidates")
                    ?: error("No response candidates returned.")
                val first = candidates.optJSONObject(0)
                    ?: error("Gemini returned an empty response.")
                val parts = first.optJSONObject("content")?.optJSONArray("parts")
                val text = buildString {
                    if (parts != null) {
                        for (i in 0 until parts.length()) {
                            append(parts.optJSONObject(i)?.optString("text").orEmpty())
                        }
                    }
                }.trim()
                if (text.isBlank()) error("Gemini returned no text.")
                text
            }
        }
    }

    suspend fun test(apiKey: String, model: String): Result<String> =
        send(
            apiKey = apiKey,
            model = model,
            history = emptyList(),
            userText = "Reply with exactly: MAYRA_OK",
            settings = AppSettings(model = model, temperature = 0f),
            systemPrompt = "You are a connection test. Reply exactly MAYRA_OK."
        )
}
