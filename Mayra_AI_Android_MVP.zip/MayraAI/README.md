# Mayra AI — Android MVP

Package: `com.mayra.ai`

This ZIP contains a functional phone-first MVP, not a static UI mockup.

## Working core features

- Gemini chat through the official Gemini REST API (`models.generateContent`)
- Secure local Gemini API-key storage using Android Keystore + AES/GCM
- Local conversation history with Room
- DataStore settings
- Bangla / English / Hindi language preference
- Android SpeechRecognizer voice input
- Android TextToSpeech voice output
- App launcher for common apps + package-name discovery
- YouTube search that opens the official YouTube app when available, otherwise YouTube web search
- Coding mode using the same Gemini brain
- Memory toggle and local-history clearing
- Error/loading states

## Important security note

A Gemini API key placed in a mobile APK can potentially be extracted by a determined attacker. This MVP lets the user enter their own key and stores it locally with Android Keystore. For a public production app, put Gemini access behind your own authenticated backend and do not ship a shared secret in the APK.

## Gemini model

The default is `gemini-3.8-flash`. Model availability changes over time, so the Settings screen allows the user to enter another currently available model name.

## Termux build

A full Android build from Termux can work, but Android SDK/Gradle setup on a phone can be heavy. The project uses standard Gradle/Android tooling.

Recommended:
1. Install a current Termux build.
2. Install JDK 17 and Gradle:
   `pkg update`
   `pkg install openjdk-17 gradle unzip git`
3. Install Android SDK command-line tools and set:
   `export ANDROID_HOME=$HOME/android-sdk`
   `export PATH=$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$PATH`
4. Accept licenses and install at least platform 35 and build-tools 35.x.
5. From this project:
   `gradle :app:assembleDebug`
6. APK:
   `app/build/outputs/apk/debug/app-debug.apk`

If Gradle/SDK setup becomes unstable on-device, edit the project in Termux and build it with Android Studio or another Linux/CI machine. The source is still a normal Android project.

## Install

Enable installation from your file manager/Termux when Android asks, then install `app-debug.apk`.

## First-run test

1. Open Mayra.
2. Settings → Gemini API.
3. Paste your own Gemini API key.
4. Save → Test.
5. Return Home and send a message.
6. Grant microphone permission when using Voice.
7. Test Phone Actions with YouTube/Chrome/Settings.
8. Test YouTube Search.
9. Test Coding mode.

## Permissions

- INTERNET: required for Gemini and YouTube web access.
- RECORD_AUDIO: only needed for voice input.
- No AccessibilityService, contacts, SMS, call-log, location, camera, or storage permissions are requested by this MVP.

## Not included in this MVP

These are deliberately not faked:
- continuous wake-word background listening
- cross-app tap automation via AccessibilityService
- direct YouTube Data API search with quota management
- PDF/image upload pipeline to Gemini
- local notifications/reminders/calendar integration
- backend authentication
- Gemini Live real-time duplex voice

They can be added as later modules.
